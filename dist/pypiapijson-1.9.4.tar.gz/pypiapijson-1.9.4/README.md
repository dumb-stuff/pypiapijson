Hello!
Here's how to use!
You can just call a function and it'll return everything you need in form of json!
You can read what it give right here!
https://warehouse.pypa.io/api-reference/json.html
# Changelog
# Version 1
First release
# Version 1.2
Add getbyv() and status
# Version 1.3
Fix some bugs
# Version 1.4
Added help
# Version 1.5
Make Changelog more readable
# Version 1.6
I am an idiot to make error
# Version 1.7
getbyv() broken
# Version 1.8
fixed getbyv()
# Version 1.9 
Fix CHANGELOGS.md
