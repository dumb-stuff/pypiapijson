import __init__

print(__init__.get("flask"));print(__init__.getbyv("pypiapijson",1));print(__init__.status())